export interface HistorialResponse {
    id: number;
    fecha: string;
    hora: string;
    destinatario: string;
    id_banco: string;
    tipo_cuenta: string;
    monto: string;
}